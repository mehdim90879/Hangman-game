﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHangman
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblWords = New System.Windows.Forms.Label()
        Me.lblDiffsettings = New System.Windows.Forms.Label()
        Me.cboDiff = New System.Windows.Forms.ComboBox()
        Me.grpKeyboard = New System.Windows.Forms.GroupBox()
        Me.btnM = New System.Windows.Forms.Button()
        Me.btnN = New System.Windows.Forms.Button()
        Me.btnB = New System.Windows.Forms.Button()
        Me.btnV = New System.Windows.Forms.Button()
        Me.btnC = New System.Windows.Forms.Button()
        Me.btnX = New System.Windows.Forms.Button()
        Me.btnZ = New System.Windows.Forms.Button()
        Me.btnL = New System.Windows.Forms.Button()
        Me.btnK = New System.Windows.Forms.Button()
        Me.btnJ = New System.Windows.Forms.Button()
        Me.btnH = New System.Windows.Forms.Button()
        Me.btnG = New System.Windows.Forms.Button()
        Me.btnF = New System.Windows.Forms.Button()
        Me.btnD = New System.Windows.Forms.Button()
        Me.btnS = New System.Windows.Forms.Button()
        Me.btnA = New System.Windows.Forms.Button()
        Me.btnP = New System.Windows.Forms.Button()
        Me.btnO = New System.Windows.Forms.Button()
        Me.btnI = New System.Windows.Forms.Button()
        Me.btnU = New System.Windows.Forms.Button()
        Me.btnY = New System.Windows.Forms.Button()
        Me.btnT = New System.Windows.Forms.Button()
        Me.btnR = New System.Windows.Forms.Button()
        Me.btnE = New System.Windows.Forms.Button()
        Me.btnW = New System.Windows.Forms.Button()
        Me.btnQ = New System.Windows.Forms.Button()
        Me.grpChosen = New System.Windows.Forms.GroupBox()
        Me.lblLetters = New System.Windows.Forms.Label()
        Me.grpLeft = New System.Windows.Forms.GroupBox()
        Me.lblLeft = New System.Windows.Forms.Label()
        Me.btnGuess = New System.Windows.Forms.Button()
        Me.btnPlay = New System.Windows.Forms.Button()
        Me.btnLevel = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.grpKeyboard.SuspendLayout()
        Me.grpChosen.SuspendLayout()
        Me.grpLeft.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblWords
        '
        Me.lblWords.BackColor = System.Drawing.Color.DarkOrange
        Me.lblWords.Location = New System.Drawing.Point(12, 9)
        Me.lblWords.Name = "lblWords"
        Me.lblWords.Size = New System.Drawing.Size(796, 71)
        Me.lblWords.TabIndex = 0
        Me.lblWords.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDiffsettings
        '
        Me.lblDiffsettings.AutoSize = True
        Me.lblDiffsettings.Location = New System.Drawing.Point(70, 96)
        Me.lblDiffsettings.Name = "lblDiffsettings"
        Me.lblDiffsettings.Size = New System.Drawing.Size(261, 28)
        Me.lblDiffsettings.TabIndex = 1
        Me.lblDiffsettings.Text = "Please choose a difficulty:"
        '
        'cboDiff
        '
        Me.cboDiff.FormattingEnabled = True
        Me.cboDiff.Items.AddRange(New Object() {"Easy", "Medium ", "Hard"})
        Me.cboDiff.Location = New System.Drawing.Point(337, 93)
        Me.cboDiff.Name = "cboDiff"
        Me.cboDiff.Size = New System.Drawing.Size(237, 36)
        Me.cboDiff.TabIndex = 2
        '
        'grpKeyboard
        '
        Me.grpKeyboard.Controls.Add(Me.btnM)
        Me.grpKeyboard.Controls.Add(Me.btnN)
        Me.grpKeyboard.Controls.Add(Me.btnB)
        Me.grpKeyboard.Controls.Add(Me.btnV)
        Me.grpKeyboard.Controls.Add(Me.btnC)
        Me.grpKeyboard.Controls.Add(Me.btnX)
        Me.grpKeyboard.Controls.Add(Me.btnZ)
        Me.grpKeyboard.Controls.Add(Me.btnL)
        Me.grpKeyboard.Controls.Add(Me.btnK)
        Me.grpKeyboard.Controls.Add(Me.btnJ)
        Me.grpKeyboard.Controls.Add(Me.btnH)
        Me.grpKeyboard.Controls.Add(Me.btnG)
        Me.grpKeyboard.Controls.Add(Me.btnF)
        Me.grpKeyboard.Controls.Add(Me.btnD)
        Me.grpKeyboard.Controls.Add(Me.btnS)
        Me.grpKeyboard.Controls.Add(Me.btnA)
        Me.grpKeyboard.Controls.Add(Me.btnP)
        Me.grpKeyboard.Controls.Add(Me.btnO)
        Me.grpKeyboard.Controls.Add(Me.btnI)
        Me.grpKeyboard.Controls.Add(Me.btnU)
        Me.grpKeyboard.Controls.Add(Me.btnY)
        Me.grpKeyboard.Controls.Add(Me.btnT)
        Me.grpKeyboard.Controls.Add(Me.btnR)
        Me.grpKeyboard.Controls.Add(Me.btnE)
        Me.grpKeyboard.Controls.Add(Me.btnW)
        Me.grpKeyboard.Controls.Add(Me.btnQ)
        Me.grpKeyboard.Enabled = False
        Me.grpKeyboard.Location = New System.Drawing.Point(12, 146)
        Me.grpKeyboard.Name = "grpKeyboard"
        Me.grpKeyboard.Size = New System.Drawing.Size(796, 231)
        Me.grpKeyboard.TabIndex = 3
        Me.grpKeyboard.TabStop = False
        Me.grpKeyboard.Tag = "Z"
        '
        'btnM
        '
        Me.btnM.BackColor = System.Drawing.Color.Orange
        Me.btnM.Location = New System.Drawing.Point(577, 155)
        Me.btnM.Name = "btnM"
        Me.btnM.Size = New System.Drawing.Size(64, 60)
        Me.btnM.TabIndex = 29
        Me.btnM.Tag = "M"
        Me.btnM.Text = "M"
        Me.btnM.UseVisualStyleBackColor = False
        '
        'btnN
        '
        Me.btnN.BackColor = System.Drawing.Color.Orange
        Me.btnN.Location = New System.Drawing.Point(507, 155)
        Me.btnN.Name = "btnN"
        Me.btnN.Size = New System.Drawing.Size(64, 60)
        Me.btnN.TabIndex = 28
        Me.btnN.Tag = "N"
        Me.btnN.Text = "N"
        Me.btnN.UseVisualStyleBackColor = False
        '
        'btnB
        '
        Me.btnB.BackColor = System.Drawing.Color.Orange
        Me.btnB.Location = New System.Drawing.Point(437, 155)
        Me.btnB.Name = "btnB"
        Me.btnB.Size = New System.Drawing.Size(64, 60)
        Me.btnB.TabIndex = 27
        Me.btnB.Tag = "B"
        Me.btnB.Text = "B"
        Me.btnB.UseVisualStyleBackColor = False
        '
        'btnV
        '
        Me.btnV.BackColor = System.Drawing.Color.Orange
        Me.btnV.Location = New System.Drawing.Point(367, 155)
        Me.btnV.Name = "btnV"
        Me.btnV.Size = New System.Drawing.Size(64, 60)
        Me.btnV.TabIndex = 26
        Me.btnV.Tag = "V"
        Me.btnV.Text = "V"
        Me.btnV.UseVisualStyleBackColor = False
        '
        'btnC
        '
        Me.btnC.BackColor = System.Drawing.Color.Orange
        Me.btnC.Location = New System.Drawing.Point(297, 155)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(64, 60)
        Me.btnC.TabIndex = 25
        Me.btnC.Tag = "C"
        Me.btnC.Text = "C"
        Me.btnC.UseVisualStyleBackColor = False
        '
        'btnX
        '
        Me.btnX.BackColor = System.Drawing.Color.Orange
        Me.btnX.Location = New System.Drawing.Point(227, 155)
        Me.btnX.Name = "btnX"
        Me.btnX.Size = New System.Drawing.Size(64, 60)
        Me.btnX.TabIndex = 24
        Me.btnX.Tag = "X"
        Me.btnX.Text = "X"
        Me.btnX.UseVisualStyleBackColor = False
        '
        'btnZ
        '
        Me.btnZ.BackColor = System.Drawing.Color.Orange
        Me.btnZ.Location = New System.Drawing.Point(157, 155)
        Me.btnZ.Name = "btnZ"
        Me.btnZ.Size = New System.Drawing.Size(64, 60)
        Me.btnZ.TabIndex = 23
        Me.btnZ.Tag = "Z"
        Me.btnZ.Text = "Z"
        Me.btnZ.UseVisualStyleBackColor = False
        '
        'btnL
        '
        Me.btnL.BackColor = System.Drawing.Color.Orange
        Me.btnL.Location = New System.Drawing.Point(647, 89)
        Me.btnL.Name = "btnL"
        Me.btnL.Size = New System.Drawing.Size(64, 60)
        Me.btnL.TabIndex = 22
        Me.btnL.Tag = "L"
        Me.btnL.Text = "L"
        Me.btnL.UseVisualStyleBackColor = False
        '
        'btnK
        '
        Me.btnK.BackColor = System.Drawing.Color.Orange
        Me.btnK.Location = New System.Drawing.Point(577, 89)
        Me.btnK.Name = "btnK"
        Me.btnK.Size = New System.Drawing.Size(64, 60)
        Me.btnK.TabIndex = 21
        Me.btnK.Tag = "K"
        Me.btnK.Text = "K"
        Me.btnK.UseVisualStyleBackColor = False
        '
        'btnJ
        '
        Me.btnJ.BackColor = System.Drawing.Color.Orange
        Me.btnJ.Location = New System.Drawing.Point(507, 89)
        Me.btnJ.Name = "btnJ"
        Me.btnJ.Size = New System.Drawing.Size(64, 60)
        Me.btnJ.TabIndex = 20
        Me.btnJ.Tag = "J"
        Me.btnJ.Text = "J"
        Me.btnJ.UseVisualStyleBackColor = False
        '
        'btnH
        '
        Me.btnH.BackColor = System.Drawing.Color.Orange
        Me.btnH.Location = New System.Drawing.Point(437, 89)
        Me.btnH.Name = "btnH"
        Me.btnH.Size = New System.Drawing.Size(64, 60)
        Me.btnH.TabIndex = 19
        Me.btnH.Tag = "H"
        Me.btnH.Text = "H"
        Me.btnH.UseVisualStyleBackColor = False
        '
        'btnG
        '
        Me.btnG.BackColor = System.Drawing.Color.Orange
        Me.btnG.Location = New System.Drawing.Point(367, 89)
        Me.btnG.Name = "btnG"
        Me.btnG.Size = New System.Drawing.Size(64, 60)
        Me.btnG.TabIndex = 18
        Me.btnG.Tag = "G"
        Me.btnG.Text = "G"
        Me.btnG.UseVisualStyleBackColor = False
        '
        'btnF
        '
        Me.btnF.BackColor = System.Drawing.Color.Orange
        Me.btnF.Location = New System.Drawing.Point(297, 89)
        Me.btnF.Name = "btnF"
        Me.btnF.Size = New System.Drawing.Size(64, 60)
        Me.btnF.TabIndex = 17
        Me.btnF.Tag = "F"
        Me.btnF.Text = "F"
        Me.btnF.UseVisualStyleBackColor = False
        '
        'btnD
        '
        Me.btnD.BackColor = System.Drawing.Color.Orange
        Me.btnD.Location = New System.Drawing.Point(227, 89)
        Me.btnD.Name = "btnD"
        Me.btnD.Size = New System.Drawing.Size(64, 60)
        Me.btnD.TabIndex = 16
        Me.btnD.Tag = "D"
        Me.btnD.Text = "D"
        Me.btnD.UseVisualStyleBackColor = False
        '
        'btnS
        '
        Me.btnS.BackColor = System.Drawing.Color.Orange
        Me.btnS.Location = New System.Drawing.Point(157, 89)
        Me.btnS.Name = "btnS"
        Me.btnS.Size = New System.Drawing.Size(64, 60)
        Me.btnS.TabIndex = 15
        Me.btnS.Tag = "S"
        Me.btnS.Text = "S"
        Me.btnS.UseVisualStyleBackColor = False
        '
        'btnA
        '
        Me.btnA.BackColor = System.Drawing.Color.Orange
        Me.btnA.Location = New System.Drawing.Point(87, 89)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(64, 60)
        Me.btnA.TabIndex = 14
        Me.btnA.Tag = "A"
        Me.btnA.Text = "A"
        Me.btnA.UseVisualStyleBackColor = False
        '
        'btnP
        '
        Me.btnP.BackColor = System.Drawing.Color.Orange
        Me.btnP.Location = New System.Drawing.Point(680, 23)
        Me.btnP.Name = "btnP"
        Me.btnP.Size = New System.Drawing.Size(64, 60)
        Me.btnP.TabIndex = 13
        Me.btnP.Tag = "P"
        Me.btnP.Text = "P"
        Me.btnP.UseVisualStyleBackColor = False
        '
        'btnO
        '
        Me.btnO.BackColor = System.Drawing.Color.Orange
        Me.btnO.Location = New System.Drawing.Point(610, 23)
        Me.btnO.Name = "btnO"
        Me.btnO.Size = New System.Drawing.Size(64, 60)
        Me.btnO.TabIndex = 12
        Me.btnO.Tag = "O"
        Me.btnO.Text = "O"
        Me.btnO.UseVisualStyleBackColor = False
        '
        'btnI
        '
        Me.btnI.BackColor = System.Drawing.Color.Orange
        Me.btnI.Location = New System.Drawing.Point(540, 23)
        Me.btnI.Name = "btnI"
        Me.btnI.Size = New System.Drawing.Size(64, 60)
        Me.btnI.TabIndex = 11
        Me.btnI.Tag = "I"
        Me.btnI.Text = "I"
        Me.btnI.UseVisualStyleBackColor = False
        '
        'btnU
        '
        Me.btnU.BackColor = System.Drawing.Color.Orange
        Me.btnU.Location = New System.Drawing.Point(470, 23)
        Me.btnU.Name = "btnU"
        Me.btnU.Size = New System.Drawing.Size(64, 60)
        Me.btnU.TabIndex = 10
        Me.btnU.Tag = "U"
        Me.btnU.Text = "U"
        Me.btnU.UseVisualStyleBackColor = False
        '
        'btnY
        '
        Me.btnY.BackColor = System.Drawing.Color.Orange
        Me.btnY.Location = New System.Drawing.Point(400, 23)
        Me.btnY.Name = "btnY"
        Me.btnY.Size = New System.Drawing.Size(64, 60)
        Me.btnY.TabIndex = 9
        Me.btnY.Tag = "Y"
        Me.btnY.Text = "Y"
        Me.btnY.UseVisualStyleBackColor = False
        '
        'btnT
        '
        Me.btnT.BackColor = System.Drawing.Color.Orange
        Me.btnT.Location = New System.Drawing.Point(330, 23)
        Me.btnT.Name = "btnT"
        Me.btnT.Size = New System.Drawing.Size(64, 60)
        Me.btnT.TabIndex = 8
        Me.btnT.Tag = "T"
        Me.btnT.Text = "T"
        Me.btnT.UseVisualStyleBackColor = False
        '
        'btnR
        '
        Me.btnR.BackColor = System.Drawing.Color.Orange
        Me.btnR.Location = New System.Drawing.Point(260, 23)
        Me.btnR.Name = "btnR"
        Me.btnR.Size = New System.Drawing.Size(64, 60)
        Me.btnR.TabIndex = 7
        Me.btnR.Tag = "R"
        Me.btnR.Text = "R"
        Me.btnR.UseVisualStyleBackColor = False
        '
        'btnE
        '
        Me.btnE.BackColor = System.Drawing.Color.Orange
        Me.btnE.Location = New System.Drawing.Point(190, 23)
        Me.btnE.Name = "btnE"
        Me.btnE.Size = New System.Drawing.Size(64, 60)
        Me.btnE.TabIndex = 6
        Me.btnE.Tag = "E"
        Me.btnE.Text = "E"
        Me.btnE.UseVisualStyleBackColor = False
        '
        'btnW
        '
        Me.btnW.BackColor = System.Drawing.Color.Orange
        Me.btnW.Location = New System.Drawing.Point(120, 23)
        Me.btnW.Name = "btnW"
        Me.btnW.Size = New System.Drawing.Size(64, 60)
        Me.btnW.TabIndex = 5
        Me.btnW.Tag = "W"
        Me.btnW.Text = "W"
        Me.btnW.UseVisualStyleBackColor = False
        '
        'btnQ
        '
        Me.btnQ.BackColor = System.Drawing.Color.Orange
        Me.btnQ.Location = New System.Drawing.Point(50, 23)
        Me.btnQ.Name = "btnQ"
        Me.btnQ.Size = New System.Drawing.Size(64, 60)
        Me.btnQ.TabIndex = 4
        Me.btnQ.Tag = "Q"
        Me.btnQ.Text = "Q"
        Me.btnQ.UseVisualStyleBackColor = False
        '
        'grpChosen
        '
        Me.grpChosen.Controls.Add(Me.lblLetters)
        Me.grpChosen.Location = New System.Drawing.Point(12, 383)
        Me.grpChosen.Name = "grpChosen"
        Me.grpChosen.Size = New System.Drawing.Size(350, 123)
        Me.grpChosen.TabIndex = 4
        Me.grpChosen.TabStop = False
        Me.grpChosen.Text = "Chosen Letters:"
        '
        'lblLetters
        '
        Me.lblLetters.Location = New System.Drawing.Point(6, 32)
        Me.lblLetters.Name = "lblLetters"
        Me.lblLetters.Size = New System.Drawing.Size(338, 78)
        Me.lblLetters.TabIndex = 10
        '
        'grpLeft
        '
        Me.grpLeft.Controls.Add(Me.lblLeft)
        Me.grpLeft.Location = New System.Drawing.Point(368, 383)
        Me.grpLeft.Name = "grpLeft"
        Me.grpLeft.Size = New System.Drawing.Size(206, 123)
        Me.grpLeft.TabIndex = 5
        Me.grpLeft.TabStop = False
        Me.grpLeft.Text = "Guesses Left:"
        '
        'lblLeft
        '
        Me.lblLeft.Location = New System.Drawing.Point(6, 32)
        Me.lblLeft.Name = "lblLeft"
        Me.lblLeft.Size = New System.Drawing.Size(194, 78)
        Me.lblLeft.TabIndex = 11
        Me.lblLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnGuess
        '
        Me.btnGuess.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGuess.Location = New System.Drawing.Point(589, 395)
        Me.btnGuess.Name = "btnGuess"
        Me.btnGuess.Size = New System.Drawing.Size(219, 111)
        Me.btnGuess.TabIndex = 6
        Me.btnGuess.Text = "Guess"
        Me.btnGuess.UseVisualStyleBackColor = True
        '
        'btnPlay
        '
        Me.btnPlay.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPlay.Location = New System.Drawing.Point(12, 528)
        Me.btnPlay.Name = "btnPlay"
        Me.btnPlay.Size = New System.Drawing.Size(230, 87)
        Me.btnPlay.TabIndex = 7
        Me.btnPlay.Text = "Play Game"
        Me.btnPlay.UseVisualStyleBackColor = True
        '
        'btnLevel
        '
        Me.btnLevel.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLevel.Location = New System.Drawing.Point(294, 528)
        Me.btnLevel.Name = "btnLevel"
        Me.btnLevel.Size = New System.Drawing.Size(230, 87)
        Me.btnLevel.TabIndex = 8
        Me.btnLevel.Text = "Change Level"
        Me.btnLevel.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(578, 528)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(230, 87)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmHangman
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.CornflowerBlue
        Me.ClientSize = New System.Drawing.Size(820, 627)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnLevel)
        Me.Controls.Add(Me.btnPlay)
        Me.Controls.Add(Me.btnGuess)
        Me.Controls.Add(Me.grpLeft)
        Me.Controls.Add(Me.grpChosen)
        Me.Controls.Add(Me.grpKeyboard)
        Me.Controls.Add(Me.cboDiff)
        Me.Controls.Add(Me.lblDiffsettings)
        Me.Controls.Add(Me.lblWords)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmHangman"
        Me.Text = "Hangman"
        Me.grpKeyboard.ResumeLayout(False)
        Me.grpChosen.ResumeLayout(False)
        Me.grpLeft.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblWords As Label
    Friend WithEvents lblDiffsettings As Label
    Friend WithEvents cboDiff As ComboBox
    Friend WithEvents grpKeyboard As GroupBox
    Friend WithEvents btnM As Button
    Friend WithEvents btnN As Button
    Friend WithEvents btnB As Button
    Friend WithEvents btnV As Button
    Friend WithEvents btnC As Button
    Friend WithEvents btnX As Button
    Friend WithEvents btnZ As Button
    Friend WithEvents btnL As Button
    Friend WithEvents btnK As Button
    Friend WithEvents btnJ As Button
    Friend WithEvents btnH As Button
    Friend WithEvents btnG As Button
    Friend WithEvents btnF As Button
    Friend WithEvents btnD As Button
    Friend WithEvents btnS As Button
    Friend WithEvents btnA As Button
    Friend WithEvents btnP As Button
    Friend WithEvents btnO As Button
    Friend WithEvents btnI As Button
    Friend WithEvents btnU As Button
    Friend WithEvents btnY As Button
    Friend WithEvents btnT As Button
    Friend WithEvents btnR As Button
    Friend WithEvents btnE As Button
    Friend WithEvents btnW As Button
    Friend WithEvents btnQ As Button
    Friend WithEvents grpChosen As GroupBox
    Friend WithEvents grpLeft As GroupBox
    Friend WithEvents btnGuess As Button
    Friend WithEvents btnPlay As Button
    Friend WithEvents btnLevel As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblLetters As Label
    Friend WithEvents lblLeft As Label
End Class
