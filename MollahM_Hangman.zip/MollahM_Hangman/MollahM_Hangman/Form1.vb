﻿Imports System.IO
Public Class frmHangman
    Private err As Boolean
    Private wordtoguess, word As String
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnPlay_Click(sender As Object, e As EventArgs) Handles btnPlay.Click
        Dim filename, possiblewords() As String
        Dim randnum As Integer

        Randomize()

        If err = True Then
            Select Case cboDiff.SelectedIndex
                Case 0
                    lblLeft.Text = 8
                    filename = "Easy.txt"
                Case 1
                    lblLeft.Text = 10
                    filename = "Medium.txt"
                Case 2
                    lblLeft.Text = 12
                    filename = "Hard.txt"
            End Select

            possiblewords = File.ReadAllLines(filename)

            randnum = Rnd() * possiblewords.Length

            wordtoguess = possiblewords(randnum)

            For count = 0 To wordtoguess.Length - 1
                lblWords.Text &= "_ "
                word &= "_"
            Next

            btnPlay.Enabled = False
            grpKeyboard.Enabled = True
            cboDiff.Enabled = False
        Else
            MessageBox.Show("Choose Difficulty!", "Difficulty", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnLevel_Click(sender As Object, e As EventArgs) Handles btnLevel.Click
        Application.Restart()
    End Sub

    Private Sub btnGuess_Click(sender As Object, e As EventArgs) Handles btnGuess.Click
        Dim guessedword As String

        If err = True Then
            guessedword = InputBox("Make a Guess:", "guess")

            If guessedword.ToUpper = wordtoguess Then
                MessageBox.Show("You Win, the word was " & wordtoguess & "!", "Win!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("You Lose, the word was " & wordtoguess & "!", "Lose!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            Application.Restart()
        Else
            MessageBox.Show("Choose Difficulty!", "Difficulty", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Application.Restart()
        End If
    End Sub

    Private Sub cmbDiff_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDiff.SelectedIndexChanged
        err = True
    End Sub

    Private Sub btn_Click(sender As Object, e As EventArgs) Handles btnQ.Click, btnW.Click, btnE.Click, btnR.Click, btnT.Click, btnY.Click, btnU.Click, btnI.Click, btnO.Click, btnP.Click, btnA.Click, btnS.Click, btnD.Click, btnF.Click, btnG.Click, btnH.Click, btnJ.Click, btnK.Click, btnL.Click, btnZ.Click, btnX.Click, btnC.Click, btnV.Click, btnB.Click, btnN.Click, btnM.Click
        Dim btn As Button
        Dim guess As Integer

        btn = sender

        lblLetters.Text &= btn.Tag

        guess = lblLeft.Text
        guess -= 1

        lblLeft.Text = guess
        btn.Enabled = False

        PlaceLetters(sender.tag)
    End Sub

    Private Sub PlaceLetters(strLetter As String) 'replaces the section of the hidden word with the proper letter.
        Dim display, guessedword As String

        For count = 0 To wordtoguess.Length - 1
            If word.Chars(count) = "_" Then
                If wordtoguess.Chars(count) = strLetter Then
                    Mid(word, count + 1) = strLetter
                End If
            End If
        Next

        display = word.Replace("_", "_ ")
        lblWords.Text = display

        If display.Contains("_") = False Then
            MessageBox.Show("You Win, the word was " & wordtoguess & "!", "Win!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Application.Restart()
        ElseIf lblLeft.Text = "0" Then
            guessedword = InputBox("Make a Guess:", "guess")

            If guessedword.ToUpper = wordtoguess Then
                MessageBox.Show("You Win, the word was " & wordtoguess & "!", "Win!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("You Lose, the word was " & wordtoguess & "!", "Lose!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            Application.Restart()
        End If
    End Sub
End Class
